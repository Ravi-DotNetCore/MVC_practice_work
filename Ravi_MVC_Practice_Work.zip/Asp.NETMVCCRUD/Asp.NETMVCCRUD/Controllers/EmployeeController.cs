﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Asp.NETMVCCRUD.Models;
using System.Data.Entity;

namespace Asp.NETMVCCRUD.Controllers
{
    public class EmployeeController : Controller
    {
        DBModel db = new DBModel();
        // GET: /Employee/
        public ActionResult Index()
        {

            return View();
        }

        public ActionResult GetData()
        {
            using (DBModel db = new DBModel())
            {
                //Getting Employee Data From Employee table 
                List<Employee> empList = db.Employees.ToList<Employee>();
                return Json(new { data = empList }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        public ActionResult AddOrEdit(int id = 0)
        {
           
            List<State> states = db.States.ToList();
            ViewBag.states = new SelectList(states, "State_Id", "State_Name");
            if (id == 0)
                return View(new Employee());
            else
            {
                using (DBModel db = new DBModel())
                {
                    return View(db.Employees.Where(x => x.EmployeeID==id).FirstOrDefault<Employee>());
                }
            }
        }
        public JsonResult GetCityList(int State_Id)
        {
            //Retrvive City List 
            db.Configuration.ProxyCreationEnabled = false;
            List<City> cities = db.Cities.Where(x => x.State_Id == State_Id).ToList();

            return Json(cities,JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult AddOrEdit(Employee emp)
        {
            using (DBModel db = new DBModel())
            { //Insert and Update Accordingly 

                if (emp.EmployeeID == 0)
                {
                    db.Employees.Add(emp);
                    db.SaveChanges();
                    return Json(new { success = true, message = "Saved Successfully" }, JsonRequestBehavior.AllowGet);
                }
                else {

                    db.Entry(emp).State = EntityState.Modified;
                    db.SaveChanges();
                    return Json(new { success = true, message = "Updated Successfully" }, JsonRequestBehavior.AllowGet);
                }
            }


        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            using (DBModel db = new DBModel())
            {
                //delete from Employee tablew 
                Employee emp = db.Employees.Where(x => x.EmployeeID == id).FirstOrDefault<Employee>();
                db.Employees.Remove(emp);
                db.SaveChanges();
                return Json(new { success = true, message = "Deleted Successfully" }, JsonRequestBehavior.AllowGet);
            }
        }
    }
}